def hello(event, context):
  return event
